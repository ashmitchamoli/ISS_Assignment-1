read file
echo "$(wc -l < $file) lines"