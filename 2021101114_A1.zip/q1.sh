echo "Part a: "
grep -v "^$" quotes.txt

echo ""
echo "Part b: "
awk '!seen[$0]++' quotes.txt    