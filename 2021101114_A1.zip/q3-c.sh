read file
echo "$(wc -w < $file) words"
