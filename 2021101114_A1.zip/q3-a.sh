read file
echo "$(wc -c < $file) bytes"