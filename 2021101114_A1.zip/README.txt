GITHUB REPO LINK: https://github.com/ashmitchamoli/ISS_Assignment-1.git
Q1
To Run: ./q1.sh
Output Format: 
Part a:
//output for part a 

Part b:
//output for part b

Q2
To Run: ./q2.sh
Output Format: 
speech.txt

Q3
To Run: ./q3-x.sh
Input Format:
//enter filename

Output Format: 
As specified in the pdf

Q4
To Run: ./q4.sh
Input Format:
//as specified

Output Format: 
As specified in the pdf

Q5
To Run: ./q2.sh
Input Format:
//enter the string

Output Format: 
//part a
//part b
//part c 